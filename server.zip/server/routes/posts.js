import express from "express";
import { createPost, deletePost, editPost, getFeedPosts } from "../controllers/posts.js";
import { verifyToken } from "../middleware/auth.js";
import { upload } from '../middleware/filemanager.js';


const router = express.Router();

// READ 
router.get("/", verifyToken, getFeedPosts)

// Post
router.post('/', verifyToken, upload.single('picture'), createPost)

/* UPDATE */
router.patch("/:id/edit", verifyToken, upload.single('picture'), editPost);
router.patch("/:id/delete", verifyToken, deletePost);

export default router;